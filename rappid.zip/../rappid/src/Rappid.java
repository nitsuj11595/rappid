/**
 * <h1>Rappid</h1>
 * 
 * Rappid is a processing library
 * for prototying Android apps<p>
 * 
 * The Rappid class is currently unused<p>
 * 
 */
package rappid;

import processing.core.PApplet;

/**
 * Unused class
 */

public class Rappid{
    /**
     *  Unused
     */
    protected Rappid(PApplet applet){
	System.out.println("Hello World");
    }
}
